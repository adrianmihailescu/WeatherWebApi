﻿using Xunit;
using CityWeatherApi.Services;
using CityWeatherApi.Data;
using Microsoft.EntityFrameworkCore;
using Moq;
using CityWeatherApi.Models.Dto;

public class CityServiceTests
{
    private readonly CityService _cityService;
    private readonly CityContext _context;

    public CityServiceTests()
    {
        var options = new DbContextOptionsBuilder<CityContext>()
            .UseInMemoryDatabase(databaseName: "TestDb")
            .Options;

        _context = new CityContext(options);

        var mockRestCountries = new Mock<RestCountriesService>(new HttpClient());
        var mockWeather = new Mock<OpenWeatherMapService>(new HttpClient(), null);

        _cityService = new CityService(_context, mockRestCountries.Object, mockWeather.Object);
    }

    [Fact]
    public async Task AddCityAsync_Should_Add_City()
    {
        var dto = new CityCreateDto
        {
            Name = "TestCity",
            State = "TestState",
            Country = "TestCountry",
            TouristRating = 4,
            DateEstablished = new DateTime(1900, 1, 1),
            EstimatedPopulation = 100000
        };

        var cityId = await _cityService.AddCityAsync(dto);

        var city = await _context.Cities.FindAsync(cityId);

        Assert.NotNull(city);
        Assert.Equal("TestCity", city.Name);
        Assert.Equal(4, city.TouristRating);
    }
}
