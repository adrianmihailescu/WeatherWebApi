using CityWeatherApi.Models;
using Microsoft.EntityFrameworkCore;

namespace CityWeatherApi.Data
{
    public class CityContext : DbContext
    {
        public CityContext(DbContextOptions<CityContext> options) : base(options) { }

        public DbSet<City> Cities { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<City>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Name).IsRequired();
                entity.Property(e => e.State).IsRequired();
                entity.Property(e => e.Country).IsRequired();
                entity.Property(e => e.TouristRating).IsRequired();
                entity.Property(e => e.DateEstablished).IsRequired();
                entity.Property(e => e.EstimatedPopulation).IsRequired();
            });

            modelBuilder.Entity<City>().HasData(
        new City
        {
            Id = 1,
            Name = "Paris",
            State = "Île-de-France",
            Country = "France",
            TouristRating = 5,
            DateEstablished = new DateTime(508, 1, 1),
            EstimatedPopulation = 2148000
        },
        new City
        {
            Id = 2,
            Name = "New York",
            State = "New York",
            Country = "USA",
            TouristRating = 4,
            DateEstablished = new DateTime(1624, 1, 1),
            EstimatedPopulation = 8419600
        },
        new City
        {
            Id = 3,
            Name = "Tokyo",
            State = "Kanto",
            Country = "Japan",
            TouristRating = 5,
            DateEstablished = new DateTime(1457, 1, 1),
            EstimatedPopulation = 13929286
        });
        }
    }
}
