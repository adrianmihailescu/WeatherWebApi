namespace CityWeatherApi.Models
{
    public class OpenWeatherResponse
    {
        public List<WeatherDescription> Weather { get; set; } = new();
        public MainInfo Main { get; set; } = new();
    }
}