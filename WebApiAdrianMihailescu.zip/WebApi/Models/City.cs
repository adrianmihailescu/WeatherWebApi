using System;

namespace CityWeatherApi.Models
{
    public class City
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
        public string State { get; set; } = null!;  // geographic sub-region
        public string Country { get; set; } = null!; // country name (local store)
        public int TouristRating { get; set; } // 1-5
        public DateTime DateEstablished { get; set; }
        public int EstimatedPopulation { get; set; }
    }
}
