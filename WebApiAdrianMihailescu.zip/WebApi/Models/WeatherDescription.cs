namespace CityWeatherApi.Models
{
    public class WeatherDescription
    {
        public string Description { get; set; } = null!;
    }
}