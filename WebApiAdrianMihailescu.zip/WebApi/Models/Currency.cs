namespace CityWeatherApi.Models
{
    public class Currency
    {
        public string Code { get; set; } = null!;
    }
}