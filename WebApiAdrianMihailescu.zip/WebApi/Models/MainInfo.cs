namespace CityWeatherApi.Models
{
    public class MainInfo
    {
        public double Temp { get; set; }
        public int Humidity { get; set; }
    }
}