namespace CityWeatherApi.Models
{
    public class CountryInfo
    {
        public string Alpha2Code { get; set; } = null!;
        public string Alpha3Code { get; set; } = null!;
        public List<Currency> Currencies { get; set; } = new();
    }
}