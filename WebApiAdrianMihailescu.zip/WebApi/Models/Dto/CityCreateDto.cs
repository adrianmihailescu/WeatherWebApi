namespace CityWeatherApi.Models.Dto;
public class CityCreateDto
{
    public string Name { get; set; } = null!;
    public string State { get; set; } = null!;
    public string Country { get; set; } = null!;
    public int TouristRating { get; set; }
    public DateTime DateEstablished { get; set; }
    public int EstimatedPopulation { get; set; }
}
