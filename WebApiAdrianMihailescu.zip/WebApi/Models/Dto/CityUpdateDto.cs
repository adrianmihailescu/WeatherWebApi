namespace CityWeatherApi.Models.Dto
{
    public class CityUpdateDto
    {
        public int TouristRating { get; set; }
        public DateTime DateEstablished { get; set; }
        public int EstimatedPopulation { get; set; }
    }
}