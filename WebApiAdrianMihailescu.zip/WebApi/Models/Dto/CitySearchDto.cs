namespace CityWeatherApi.Models.Dto
{
    public class CitySearchResultDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
        public string State { get; set; } = null!;
        public string Country { get; set; } = null!;
        public int TouristRating { get; set; }
        public DateTime DateEstablished { get; set; }
        public int EstimatedPopulation { get; set; }

        public string CountryCode2 { get; set; } = null!;
        public string CountryCode3 { get; set; } = null!;
        public string CurrencyCode { get; set; } = null!;

        public WeatherDto Weather { get; set; } = null!;
    }
}