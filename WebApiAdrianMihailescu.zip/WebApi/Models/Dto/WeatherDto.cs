public class WeatherDto
{
    public string Description { get; set; } = null!;
    public double TemperatureCelsius { get; set; }
    public int Humidity { get; set; }
}