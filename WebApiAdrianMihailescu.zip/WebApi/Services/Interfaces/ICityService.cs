using CityWeatherApi.Models.Dto;

namespace CityWeatherApi.Services.Interfaces
{
    public interface ICityService
    {
        Task<int> AddCityAsync(CityCreateDto dto);
        Task<bool> UpdateCityAsync(int cityId, CityUpdateDto dto);
        Task<bool> DeleteCityAsync(int cityId);
        Task<List<CitySearchResultDto>> SearchCityByNameAsync(string cityName);
        Task<CitySearchResultDto?> GetCityByIdAsync(int cityId);

    }
}