using CityWeatherApi.Data;
using CityWeatherApi.Models;
using CityWeatherApi.Models.Dto;
using CityWeatherApi.Services;
using CityWeatherApi.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace CityWeatherApi.Services
{

    public class CityService : ICityService
    {
        private readonly CityContext _context;
        private readonly RestCountriesService _restCountries;
        private readonly OpenWeatherMapService _weatherService;

        public CityService(CityContext context, RestCountriesService restCountries, OpenWeatherMapService weatherService)
        {
            _context = context;
            _restCountries = restCountries;
            _weatherService = weatherService;
        }

        public async Task<int> AddCityAsync(CityCreateDto dto)
        {
            var city = new City
            {
                Name = dto.Name,
                State = dto.State,
                Country = dto.Country,
                TouristRating = dto.TouristRating,
                DateEstablished = dto.DateEstablished,
                EstimatedPopulation = dto.EstimatedPopulation
            };
            _context.Cities.Add(city);
            await _context.SaveChangesAsync();
            return city.Id;
        }

        public async Task<bool> UpdateCityAsync(int cityId, CityUpdateDto dto)
        {
            var city = await _context.Cities.FindAsync(cityId);
            if (city == null)
                return false;

            city.TouristRating = dto.TouristRating;
            city.DateEstablished = dto.DateEstablished;
            city.EstimatedPopulation = dto.EstimatedPopulation;

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteCityAsync(int cityId)
        {
            var city = await _context.Cities.FindAsync(cityId);
            if (city == null)
                return false;

            _context.Cities.Remove(city);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<List<CitySearchResultDto>> SearchCityByNameAsync(string cityName)
        {
            var cities = await _context.Cities
                .Where(c => c.Name.ToLower() == cityName.ToLower())
                .ToListAsync();

            var results = new List<CitySearchResultDto>();

            foreach (var city in cities)
            {
                var countryInfo = await _restCountries.GetCountryByNameAsync(city.Country);
                var weather = await _weatherService.GetWeatherAsync(city.Name);

                if (countryInfo == null || weather == null)
                    continue;

                results.Add(new CitySearchResultDto
                {
                    Id = city.Id,
                    Name = city.Name,
                    State = city.State,
                    Country = city.Country,
                    TouristRating = city.TouristRating,
                    DateEstablished = city.DateEstablished,
                    EstimatedPopulation = city.EstimatedPopulation,
                    CountryCode2 = countryInfo.Alpha2Code,
                    CountryCode3 = countryInfo.Alpha3Code,
                    CurrencyCode = countryInfo.Currencies.FirstOrDefault()?.Code ?? "",
                    Weather = weather
                });
            }

            return results;
        }

        public async Task<CitySearchResultDto?> GetCityByIdAsync(int cityId)
        {
            var city = await _context.Cities.FindAsync(cityId);
            if (city == null)
                return null;

            var countryInfo = await _restCountries.GetCountryByNameAsync(city.Country);
            var weather = await _weatherService.GetWeatherAsync(city.Name);

            if (countryInfo == null || weather == null)
                return null;

            return new CitySearchResultDto
            {
                Id = city.Id,
                Name = city.Name,
                State = city.State,
                Country = city.Country,
                TouristRating = city.TouristRating,
                DateEstablished = city.DateEstablished,
                EstimatedPopulation = city.EstimatedPopulation,
                CountryCode2 = countryInfo.Alpha2Code,
                CountryCode3 = countryInfo.Alpha3Code,
                CurrencyCode = countryInfo.Currencies.FirstOrDefault()?.Code ?? "",
                Weather = weather
            };
        }

    }
}