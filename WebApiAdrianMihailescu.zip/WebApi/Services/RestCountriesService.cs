using System.Net.Http.Json;
using System.Threading.Tasks;
using System.Linq;
using System.Collections.Generic;

namespace CityWeatherApi.Services
{
    public class RestCountriesService
    {
        private readonly HttpClient _httpClient;

        public RestCountriesService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<CountryInfo?> GetCountryByNameAsync(string countryName)
        {
            var url = $"https://restcountries.com/v2/name/{countryName}?fullText=true";
            var response = await _httpClient.GetFromJsonAsync<List<CountryInfo>>(url);

            return response?.FirstOrDefault();
        }
    }

    public class CountryInfo
    {
        public string Alpha2Code { get; set; } = null!;
        public string Alpha3Code { get; set; } = null!;
        public List<Currency> Currencies { get; set; } = new();
    }

    public class Currency
    {
        public string Code { get; set; } = null!;
    }
}
