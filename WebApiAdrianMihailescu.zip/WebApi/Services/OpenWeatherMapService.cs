using System.Net.Http.Json;
using System.Threading.Tasks;
using CityWeatherApi.Models;

namespace CityWeatherApi.Services
{
    public class OpenWeatherMapService
    {
        private readonly HttpClient _httpClient;
        private readonly string _apiKey;

        public OpenWeatherMapService(HttpClient httpClient, IConfiguration configuration)
        {
            _httpClient = httpClient;
            _apiKey = configuration["OpenWeatherMapApiKey"] ?? throw new ArgumentNullException("OpenWeatherMapApiKey");
        }

        public async Task<WeatherDto?> GetWeatherAsync(string cityName)
        {
            var url = $"https://api.openweathermap.org/data/2.5/weather?q={cityName}&appid={_apiKey}&units=metric";

            var response = await _httpClient.GetFromJsonAsync<OpenWeatherResponse>(url);

            if (response == null)
                return null;

            return new WeatherDto
            {
                Description = response.Weather.FirstOrDefault()?.Description ?? "",
                TemperatureCelsius = response.Main.Temp,
                Humidity = response.Main.Humidity
            };
        }
    }
}
