using Microsoft.AspNetCore.Mvc;
using CityWeatherApi.Models.Dto;
using CityWeatherApi.Services.Interfaces;

[ApiController]
[Route("api/[controller]")]
public class CitiesController : ControllerBase
{
    private readonly ICityService _cityService;

    public CitiesController(ICityService cityService)
    {
        _cityService = cityService;
        Console.WriteLine("CitiesController initialized");
    }

    [HttpPost]
    public async Task<IActionResult> AddCity([FromBody] CityCreateDto dto)
    {
        var cityId = await _cityService.AddCityAsync(dto);
        return CreatedAtAction(nameof(GetCity), new { id = cityId }, new { id = cityId });
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateCity(int id, [FromBody] CityUpdateDto dto)
    {
        var updated = await _cityService.UpdateCityAsync(id, dto);
        if (!updated) return NotFound();
        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteCity(int id)
    {
        var deleted = await _cityService.DeleteCityAsync(id);

        if (!deleted)
            return NotFound();

        return NoContent();
    }

    [HttpGet("search")]
    public async Task<IActionResult> SearchCity([FromQuery] string name)
    {
        Console.WriteLine($"Searching for city: {name}");
        var results = await _cityService.SearchCityByNameAsync(name);

        if (results.Count == 0)
            return NotFound();

        return Ok(results);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetCity(int id)
    {
        var city = await _cityService.GetCityByIdAsync(id);
        if (city == null)
            return NotFound();

        return Ok(city);
    }
}
