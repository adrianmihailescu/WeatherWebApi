﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace WebApi.Migrations
{
    /// <inheritdoc />
    public partial class SeedInitialCities : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Cities",
                columns: new[] { "Id", "Country", "DateEstablished", "EstimatedPopulation", "Name", "State", "TouristRating" },
                values: new object[,]
                {
                    { 1, "France", new DateTime(508, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), 2148000, "Paris", "Île-de-France", 5 },
                    { 2, "USA", new DateTime(1624, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), 8419600, "New York", "New York", 4 },
                    { 3, "Japan", new DateTime(1457, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), 13929286, "Tokyo", "Kanto", 5 }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Cities",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Cities",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Cities",
                keyColumn: "Id",
                keyValue: 3);
        }
    }
}
